package com.miniyo.tamagotchi;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new AI(), "AndroidAI");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }

    public class AI {
        @JavascriptInterface public String understand(String text, String historyJson) {
            String t = text == null ? "" : text.trim();
            String l = t.toLowerCase(Locale.ROOT);
            String intent="unknown", emotion="confundida", sprite="Confundida", reply="Mmm… cuéntame un poquito más 💗";
            if (contains(l,"casamiento","casar","casarme","boda","novia","novio","esposa","esposo","matrimonio")) {
                intent="wedding"; emotion="enamorada"; sprite="Novia"; reply="¿Una boda? 💍💗";
            } else if (contains(l,"te amo","te quiero","te adoro","amor","linda","bella","tierna","preciosa")) {
                intent="affection"; emotion="enamorada"; sprite="Enamorada"; reply="Awww… 💗";
            } else if (contains(l,"te odio","idiota","estúpida","estupida","tonta","cállate","callate")) {
                intent="insult"; emotion="ofendida"; sprite="Ofendida"; reply="¡Oye! 😤";
            } else if (contains(l,"golpear","golpearte","pegarte","pegar","patada","puñetazo","puñetazos","violencia","hacerte daño","hacerte dano")) {
                intent="violence"; emotion="enojada"; sprite="Muy enojada"; reply="¡Eso no! 😠";
            } else if (contains(l,"triste","pena","llorando","llorar","día horrible","dia horrible","me siento mal","no estoy bien","me abandonaste")) {
                intent="sadness"; emotion="triste"; sprite="Llorando"; reply="Ven… 🥺💗";
            } else if (contains(l,"hambre","comer","comida","manzana","pizza","pastel","helado","chocolate","dulce")) {
                intent="food"; emotion="happy"; sprite="Comiendo manzana"; reply="Ñam ñam 🍎";
            } else if (contains(l,"sí","si","siii","claro","por supuesto","sí quiero","si quiero")) {
                intent="yes"; emotion="happy"; sprite="Símbolo OK"; reply="¡Siii! ✨";
            } else if (contains(l,"gracias","genial","perfecto","me encanta","qué linda","que linda","qué bonito","que bonito","feliz")) {
                intent="positive"; emotion="happy"; sprite="Feliz"; reply="Jejeje, qué lindo 💕";
            } else if (contains(l,"por qué","porque","qué significa","que significa","cómo","como","explícame","explica","qué es","que es")) {
                intent="question"; emotion="confused"; sprite="Confundida"; reply="Mmm… 🤔";
            } else if (t.length < 2) {
                intent="empty"; emotion="default"; sprite="Default"; reply="";
            }
            try {
                JSONObject o=new JSONObject(); o.put("intent",intent); o.put("emotion",emotion); o.put("sprite",sprite); o.put("reply",reply); return o.toString();
            } catch(Exception e){ return "{\"intent\":\"unknown\",\"emotion\":\"confundida\",\"sprite\":\"Confundida\",\"reply\":\"Mmm… 🤔\"}"; }
        }
        private boolean contains(String s,String... xs){ for(String x:xs) if(s.contains(x)) return true; return false; }
    }
}

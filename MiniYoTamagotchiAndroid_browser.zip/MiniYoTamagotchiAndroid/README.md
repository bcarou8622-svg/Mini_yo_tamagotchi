# Mini Yo Tamagotchi — APK desde el navegador

Este proyecto usa como base la versión elegida del juego HTML autocontenido y la envuelve en una app Android mediante WebView.

## Qué incluye

- Los 13 sprites de la base, sin eliminarlos.
- Música y sonidos existentes.
- Decoraciones e interacciones de la versión base.
- Acariciar la cabeza: desliza el dedo por la zona superior de la cabeza y activa **Enamorada + corazones + sonido**.
- Puente `AndroidAI` para interpretación local estructurada (`intent`, `emotion`, `sprite`, `reply`).
- Workflow de GitHub Actions que compila automáticamente un APK Debug y lo deja como archivo descargable.

## Compilar únicamente con el teléfono

No necesitas Android Studio ni un PC. Puedes usar GitHub desde Chrome en Android.

### 1. Crear el repositorio

Entra en GitHub, crea un repositorio nuevo y déjalo vacío.

### 2. Subir los archivos

Sube **el contenido de esta carpeta**, no el ZIP, conservando la estructura de carpetas.

Es especialmente importante conservar:

- `.github/workflows/build-apk.yml`
- `app/`
- `build.gradle`
- `settings.gradle`

### 3. Esperar la compilación

Cada vez que subas cambios, GitHub Actions ejecutará `Crear APK de Mini Yo Tamagotchi`.

También puedes abrir la pestaña **Actions**, elegir ese workflow y pulsar **Run workflow**.

### 4. Descargar el APK

Cuando termine correctamente:

**Actions → Crear APK de Mini Yo Tamagotchi → ejecución terminada → Artifacts → MiniYoTamagotchi-debug**

Descarga el ZIP del artifact, ábrelo en el teléfono y extrae `app-debug.apk`. Después toca el APK para instalarlo.

Android puede pedir permiso para instalar aplicaciones desde el navegador o gestor de archivos. Ese permiso se concede desde los ajustes de Android y depende de la versión del sistema.

## IA

La capa `AndroidAI` actual funciona localmente como fallback. La arquitectura deja separada la interpretación para poder conectarla posteriormente a un backend de IA más potente. No se debe guardar una API key privada dentro del APK.
